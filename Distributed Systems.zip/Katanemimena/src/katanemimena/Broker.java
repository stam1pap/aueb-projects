package katanemimena;


import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Broker implements Node
{
    private boolean active;
    private ServerSocket ss;
    private int port;
    private int id;
    private int hash;
    
    private ArrayList<MusicFile> songs;

    private ArrayList<NodeConnectionInfo> registeredConsumers;
    private ArrayList<NodeConnectionInfo> publishersConnectioInfo;      // plirofories gia tin sindesi me tous publisher
    private ArrayList<NodesSockets> registeredPublishers;
    
    public Broker(int id, int port, ArrayList<NodeConnectionInfo> brokers, ArrayList<NodeConnectionInfo> publishers)
    {
        Broker.brokers.addAll(brokers);
        
        this.registeredPublishers = new ArrayList<NodesSockets>();
        this.publishersConnectioInfo = publishers;
        
        for (NodeConnectionInfo publisher : publishers) {
            this.registeredPublishers.add( new NodesSockets(publisher) );
        }
        
        this.songs = new ArrayList<MusicFile>();
        this.registeredConsumers = new ArrayList<>();
        
        this.port = port;
        this.active = true;
    }
    
    @Override
    public void init()
    {
        // ipologismos kleidiwn
        calculateKeys();
        
        // sindesi me tous publisher kai apostoli tou hash
        for (int i = 0; i < registeredPublishers.size(); i++)
        {
            System.out.print("Updating publisher "+publishersConnectioInfo.get(i).id+" ... ");
            
            registeredPublishers.get(i).connect();
            registeredPublishers.get(i).sendObject( "update" );
            registeredPublishers.get(i).sendObject( brokers );
            publishersConnectioInfo.get(i).filesList = (ArrayList<MusicFile>) registeredPublishers.get(i).receiveObject();
            
            System.out.println("done");
        }
        
        
        try {
            
            // syndesi apo tous consumer
            connect();
            
            do{
            
                // molis syndethei neos consumer
                Socket newClient = ss.accept();
                
                // ftianei kai ena nima
                ThreadBroker threadBroker = new ThreadBroker(newClient, publishersConnectioInfo, hash);
                threadBroker.start();
                
                
            }while( active == true );
            
            
            // aposyndesi
            disconnect();
        }
        catch (IOException ex)
        {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }

        
        // aposindesi me tous subscriber kai apostoli tou hash
        for (NodesSockets registeredPublisher : registeredPublishers)
        {
            registeredPublisher.disconnect();
        }
                
    }


    @Override
    public ArrayList<NodeConnectionInfo> getBrokers()
    {
        return brokers;
    }

    
    @Override
    public void connect()
    {
        try {
            
            // Anoigei socket gia na dexetai syndeseis apo tous consumers kai ta nimata tous
            ss = new ServerSocket(port);
            
        } catch (IOException ex) {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void disconnect()
    {
        try {
            
            // Kleinei to server socket
            ss.close();
            
        } catch (IOException ex) {
            Logger.getLogger(Publisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void calculateKeys()
    {
        // gia kathe broker ypologixei to hash tou
        for (NodeConnectionInfo broker : brokers)
        {
            broker.setHash( brokers.size() );
            
            // enimerwnei kai to dikou hash
            if ( broker.id == id)
            {
                hash = broker.hash;
            }
        }
    }
    
    
    public static void main(String[] args)
    {
        ArrayList<NodeConnectionInfo> brokers = new ArrayList<>();
        brokers.add(new NodeConnectionInfo(0, "127.0.0.1", 4000));
//        brokers.add(new katanemimena.NodeConnectionInfo(1, "127.0.0.1", 4001));
//        brokers.add(new katanemimena.NodeConnectionInfo(2, "127.0.0.1", 4002));
        
        ArrayList<NodeConnectionInfo> publishers = new ArrayList<>();
        publishers.add( new NodeConnectionInfo(0, "127.0.0.1", 5000) );
//        publishers.add( new katanemimena.NodeConnectionInfo(1, "127.0.0.1", 5001) );
//        publishers.add( new katanemimena.NodeConnectionInfo(2, "127.0.0.1", 5002) );
        
        Broker broker = new Broker(0, 4000, brokers, publishers);
//        katanemimena.Broker broker = new katanemimena.Broker(1, 4001, brokers, publishers);
        //katanemimena.Broker broker = new katanemimena.Broker(2, 4002, brokers, publishers);
        
        broker.init();
    }
}
