package katanemimena;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Consumer implements Node
{
    private String folderName;
    
    private Socket brokerSocket;
    private ObjectOutputStream out;
    private ObjectInputStream in;
    private NodeConnectionInfo selectedBroker;
    
    public Consumer(int id, ArrayList<NodeConnectionInfo> brokers)
    {
        this.folderName = "Consumer_"+id;
        
        // apothikeuei olous tous consumer
        Publisher.brokers.addAll(brokers);
    }
    
    

    @Override
    public void init()
    {
        Scanner scanner = new Scanner(System.in);
        
        // dimiourgia fakelou pou tha katevainoun ta tragoudia tou
        File dir = new File(folderName);
        dir.mkdir();
        
        
        // epilogi tyxaiou broker kai syndesi me auton
        Random random = new Random();
        int i = random.nextInt( Publisher.brokers.size() );
        
        selectedBroker = brokers.get(i);
        
        try {
            
            do{
        
            
                System.out.println("Type the artist or type exit: ");
                String artistName = scanner.nextLine();
                
                if( artistName.equals("exit") )
                {
                    break;
                }
                
                // sindesi me ton katallito broker
                if(register(selectedBroker, artistName) == false)
                {
                    System.out.println("Artist "+artistName+" doesn't exist");
                    continue;
                }
                
                // dwse to onoma tou tragoudiou
                System.out.println("Type the song: ");
                String songName = scanner.nextLine();
                
                //out.writeObject( artistName );
                out.writeObject( songName );
                out.flush();
                
                boolean songFound = in.readBoolean();
                
                if(songFound == true)
                {
                    // xekinaei na apothikeuei to arxeio
                    saveSong( folderName, songName );
                }
                else
                {
                    System.out.println("Song "+songName+" hasn't been found");
                }
            
            
            
            }while(true);
        
        } catch (IOException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
        
            // aposyndesi sto telos
            disconnect();
        }
    }

    
    private void playData(String artistName, Value v)
    {
        System.out.println("Playing "+v.musicFile.trackName+" ("+artistName+")");
        System.out.println("Genre "+v.musicFile.genre);
        System.out.println("Info "+v.musicFile.albumInfo);
    }
    

    // Ginetai register me kapoion broker, epistrefei true/flalse an einai o sostos
    public boolean register(NodeConnectionInfo b, String artistName)
    {
        boolean correctBroker = false;
        boolean response;
        
        try {
            
            selectedBroker = b;
            
            connect();
            
            // koitazei na dei an to exei h na syndethei me allon broker
            out.writeObject(artistName);
            out.flush();
            
            response = in.readBoolean();
            
            if(response == false)
            {
                selectedBroker = (NodeConnectionInfo) in.readObject();
                
                // aposidensi kai syndesi sto neo broker
                disconnect();
                connect();
                
                // apostoli tou kallitexni kai ston allo broker
                out.writeObject(artistName);
                out.flush();
                response = in.readBoolean();
                
                if(response == true)
                {
                    correctBroker = true;
                }
            }
            else
            {
                correctBroker = true;
            }

            
        } catch (IOException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally{
            return correctBroker;
        }
    }
    
    @Override
    public void connect()
    {
        try {
            
            // anoigei to socket me ton broker
            brokerSocket = new Socket( selectedBroker.ip , selectedBroker.port);
            
            // Stream gia in kai out
            out = new ObjectOutputStream( brokerSocket.getOutputStream() );
            in = new ObjectInputStream(brokerSocket.getInputStream());
            
            
        } catch (IOException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void disconnect()
    {
        try {
            
            in.close();
            out.close();
            brokerSocket.close();
            
        } catch (IOException ex) {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public ArrayList<NodeConnectionInfo> getBrokers()
    {
        return brokers;
    }

    private void saveSong(String folderName, String songName)
    {
        String topic;
        Value value;
        long lengthRead;
        long totalLengthReceived = 0;
        OutputStream outputStream = null;
        
        try {
            
            outputStream = new FileOutputStream( folderName+"/"+songName+".mp3" );
            
            do{
                // anagnwsi tou topic - value
                topic = (String) in.readObject();
                value = (Value) in.readObject();
                
                // grapsimo tou chunk sto arxeio
                if( totalLengthReceived + value.musicFile.musicFileExtract.length > value.musicFile.fileLength)
                    outputStream.write( value.musicFile.musicFileExtract, 0, (int)(value.musicFile.fileLength - totalLengthReceived) );
                else
                    outputStream.write( value.musicFile.musicFileExtract );

                    
                totalLengthReceived = totalLengthReceived + value.musicFile.musicFileExtract.length;


                // Oso den exei diavasei olo to arxeio
            }while( totalLengthReceived < value.musicFile.fileLength );
            
            System.out.println("File "+songName+" downloaded");
        }
        catch (FileNotFoundException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (IOException ex)
        {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (ClassNotFoundException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
        finally
        {
            try {
                outputStream.close();
            } catch (IOException ex) {
                Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    public static void main(String[] args)
    {
        ArrayList<NodeConnectionInfo> brokers = new ArrayList<>();
        brokers.add(new NodeConnectionInfo(0, "127.0.0.1", 4000));
//        brokers.add(new katanemimena.NodeConnectionInfo(1, "127.0.0.1", 4001));
//        brokers.add(new katanemimena.NodeConnectionInfo(2, "127.0.0.1", 4002));
        
        
        Consumer consumer = new Consumer(0, brokers);
        consumer.init();
    }
    
}
