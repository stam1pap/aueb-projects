package katanemimena;

import java.io.Serializable;


public class MusicFile implements Serializable
{
    public String trackName;
    public String artistName;
    public String albumInfo;
    public String genre;
    public String path;                     // monopati arxeiou gia na mporei na to anoixei
    public long fileLength;
    public byte [] musicFileExtract;

    public MusicFile(String trackName, String artistName, String albumInfo, String genre, String path, long fileLength) {
        this.trackName = trackName;
        this.artistName = artistName;
        this.albumInfo = albumInfo;
        this.genre = genre;
        this.path = path;
        this.fileLength = fileLength;
    }

    MusicFile(MusicFile musicFile)
    {
        this.trackName = musicFile.trackName;
        this.artistName = musicFile.artistName;
        this.albumInfo = musicFile.albumInfo;
        this.genre = musicFile.genre;
        this.path = musicFile.path;
        this.fileLength = musicFile.fileLength;
        
        setMusicFileExtract(musicFile.musicFileExtract);
    }

    
    public void setMusicFileExtract(byte[] musicFileExtract)
    {
        this.musicFileExtract = new byte[ musicFileExtract.length ];
        for (int i = 0; i < musicFileExtract.length; i++)
        {
            this.musicFileExtract[i] = musicFileExtract[i];
            
        }
    }
}
