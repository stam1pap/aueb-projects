package katanemimena;

import java.util.ArrayList;

public interface Node 
{
    public static ArrayList<NodeConnectionInfo> brokers = new ArrayList<NodeConnectionInfo>();
    
    public void init();
    
    public void connect();
    
    public void disconnect();
    
    public ArrayList<NodeConnectionInfo> getBrokers();
}
