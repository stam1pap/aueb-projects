package katanemimena;// Klassi me ta stoixeia pou xreiazetai kapoios gia na syndethei me enan broker

import java.io.Serializable;
import java.util.ArrayList;

public class NodeConnectionInfo implements Serializable
{
    public String ip;
    public int port;
    public int id;
    public int hash;
    public ArrayList<MusicFile> filesList;

    public NodeConnectionInfo(int id ,String ip, int port) {
        this.ip = ip;
        this.port = port;
        this.id = id;
    }

    // Ypologizei to hash me vasi to plithos twn broker
    public void setHash(int brokersNum) {
        
        // Ypologsimos tou hash
        HashFunction hashFunction = new HashFunction( brokersNum );
        this.hash = hashFunction.calculateHash(ip);
    }
    
    
}
