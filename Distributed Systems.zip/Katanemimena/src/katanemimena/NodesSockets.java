package katanemimena;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

// exei ta stoixeia gia tin epikoinwnia me kapoion komvo
public class NodesSockets
{
    public Socket nodeSocket;
    public ObjectOutputStream out;
    public ObjectInputStream in;
    private NodeConnectionInfo nodeConnectioInfo;

    public NodesSockets( NodeConnectionInfo nci ) {
        
        this.nodeConnectioInfo = nci;
    }
    
    public void connect()
    {
        try {
            
            // anoigei to socket me ton broker
            nodeSocket = new Socket( nodeConnectioInfo.ip , nodeConnectioInfo.port);
            
            // stream gia in kai out
            out = new ObjectOutputStream( nodeSocket.getOutputStream() );
            in = new ObjectInputStream(nodeSocket.getInputStream());
            
            
        } catch (IOException ex) {
            Logger.getLogger(Consumer.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void sendObject( Object obj )
    {
        try {
            
            out.writeObject(obj);
            out.flush();
        }
        catch (IOException ex)
        {
            Logger.getLogger(NodesSockets.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public Object receiveObject(  )
    {
        Object h = null;
        
        try {
            
            h = in.readObject();
        }
        catch (IOException ex)
        {
            Logger.getLogger(NodesSockets.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(NodesSockets.class.getName()).log(Level.SEVERE, null, ex);
        }

        return h;
    }
    
    public void disconnect()
    {
        try {
            
            in.close();
            out.close();
            nodeSocket.close();
            
        } catch (IOException ex) {
            Logger.getLogger(ThreadPublisher.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
