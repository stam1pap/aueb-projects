package katanemimena;

import java.io.Serializable;


public class PublisherPerMusicFile implements Serializable
{
    public int publisher_id;
    public MusicFile musicFile;

    public PublisherPerMusicFile(int publisher_id, MusicFile musicFile)
    {
        this.publisher_id = publisher_id;
        this.musicFile = musicFile;
    }
}
