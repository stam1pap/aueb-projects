package katanemimena;

import java.io.Serializable;


public class Value implements Serializable
{
    public MusicFile musicFile;

    public Value(MusicFile musicFile)
    {
        this.musicFile = new MusicFile(musicFile);
    }
}
