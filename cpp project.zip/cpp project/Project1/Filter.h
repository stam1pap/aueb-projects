#pragma once
#include "Image.h"

using namespace image;
class Filter {
public: 

	virtual Image operator <<(const Image& image) = 0;
};
