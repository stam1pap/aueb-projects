#include "FilterGamma.h"


Image FilterGamma::operator <<(const Image& image) {

    //epeidh exw const xreiazomai ena antigrafo image
    Image newimage = image;
    for (int i = 0; i < newimage.getWidth(); i++) {
        for (int j = 0; j < newimage.getHeight(); j++) {
            Vec3 <float>& p = newimage(i, j);// xreisimopoioume anafora etsi wste na allazei katefteian to rgb tou (disdiastaoy pinaka)
            //den uparxei katallhlh synarthsh gia na ypswsw sto vec3 pou einai enwmeno rgb ara prepei na to kanw xexwrista
            p.r = pow(p.r,gam);
            p.g = pow(p.g, gam);
            p.b = pow(p.b, gam);
            //se periptwsh pou exw fygei ektos oriwn 0,1
            p = p.clampToLowerBound(0.0);
            p = p.clampToUpperBound(1.0);
        }
    }

    return newimage;
}

FilterGamma::FilterGamma(float gamma) {
	gam = gamma;
}