#pragma once
#include "Filter.h"


class FilterGamma : public Filter {
	float gam;
public :


	Image operator <<(const Image& image);
	FilterGamma(float gamma);

};