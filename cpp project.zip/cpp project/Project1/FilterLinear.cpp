#include "FilterLinear.h"
 
//sou dinw mia eikona kai thelw pisw ena iamge me thn allagmenh eikona
Image FilterLinear::operator <<(const Image& image) {

  //epeidh exw const xreiazomai ena antigrafo image
    Image newimage = image;
    for (int i = 0; i < newimage.getWidth(); i++) {
        for (int j = 0; j < newimage.getHeight(); j++) {
           Vec3 <float> &p= newimage(i,j);// xreisimopoioume anafora etsi wste na allazei katefteian to rgb tou (disdiastaoy pinaka)
           p = a * p + c;
           //se periptwsh pou exw fygei ektos oriwn 0,1
           p = p.clampToLowerBound(0.0);
           p = p.clampToUpperBound(1.0);
        }
    }

    return newimage;
}

FilterLinear::FilterLinear(Vec3<float> a, Vec3<float> c) {
        this->a = a;
        this->c = c;
}