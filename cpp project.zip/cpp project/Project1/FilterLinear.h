#pragma once
#include "Filter.h"
#include "vec3.h"


using namespace math;

class FilterLinear : public Filter {
	Vec3<float> a, c;
public:
	Image operator <<(const Image& image);
	FilterLinear(Vec3<float> a, Vec3<float> c);

};
