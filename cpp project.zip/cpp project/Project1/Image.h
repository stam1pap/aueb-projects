#pragma once //estw oti exw polla cpp kai polla .h ,mporei polla cpp na klhronomoun to idio cpp tote to .h den kaleitai oles tis fores gia kathe
//cpp arxeio...vazw to pragma once gia na mhn kalesei tis synarthseis perissoteres apo mia fores
#include "vec3.h"
#include "imageio.h"
#include "array2d.h"
#include <iostream>
#include <vector>

//klhronomei taftoxrona thn imageio kai thn array2d pou einai template 
//to vec3 einai ena rgb kai otan ginetai h exeidikefsh tote einai float
//H image einai antikeimeno pou exei ton pinaka mas me stoixeia 
using namespace math;
namespace image {
	class Image :public  Array2D <Vec3<float>>, public ImageIO {
	public:
		virtual bool load(const std::string& filename, const std::string& format);
		
		virtual bool save(const std::string& filename, const std::string& format);
		



	};
}