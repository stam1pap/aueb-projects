#include "array2d.h"
#include <iostream>
#include <vector>

//FTIAXNW TA UPOLOIPA
//FTIAXNW KAI IMAGE.H POU KLHRONOMEI TO TEMPPLATE KAI MIA KLASH ,GIA TO TEMPLATE THELW KAI EXHDEIKEFSH

// to buffer eexei ta xrwmata ths eikonas
//sthn arxh krataei T alla meta to T ginetai rgb enwmeno ara den xreiazetai na exw bhma 3
//sthn set data kalw pinaka alla thelw na antigrapsw ta stoixeia tou vector 
//ara elegxw an platos upsos != 0 kanw thn antigrafh


//loipoooooooooon,otan kanoume read ftiaxnoume ena table me ena ena bit meta xrhsimopoioume ena buffer tupou vector
//poy einai ousiastika ta stoixeia dataptr....o buffer se ena keli exei ta tria xrwmata
//ena antikeimeno dhladh exei ta rgb
//ena antikeimeno array2d exei ta exhs pedia: 1)YPSOS,2)BAROS,3)BUFFER
//O BUFFER EXEI MHKOS P*Y KAI EINAI MONODIASTATOS ENW PARISTANEI DYSDIASTTO

	using namespace std;

	namespace math {

		template <typename T>//h 
		const unsigned int Array2D<T>::getWidth() const {// prepei na deixw apo pou pairnw tis methodous aftes

			return width;
		}
		template <typename T>
		const unsigned int Array2D<T>::getHeight() const {

			return height;
		}

		template <typename T>
		T* Array2D<T>::getRawDataPtr() {

			return &buffer[0]; //vector =pinaks pou afxomeiwnetai dynamika giafto thelw T* (opws string*)

		}

		template <typename T>
		void Array2D<T>::setData(const T* const& data_ptr) {
			if (width == 0 || height == 0) {
				
			}
			else {
				for (int i = 0; i < width * height; i++) {
					buffer[i]=data_ptr[i];//exoume diavasei ta stoixeia kai ta pername ston buffer
				}
			}

		}

		template <typename T>
	T& Array2D<T>::operator () (unsigned int x, unsigned int y) {
		if (x < width && y < height) {

			return buffer[y * width + x];//AFTA TA BLEPOUME FIATI EINAI STO HEADER
		}
		else {
		       	return buffer[0];
		}
	}

	template <typename T>
		Array2D<T>::Array2D(unsigned int width, unsigned int height, const T* data_ptr):buffer(width* height) { //constr
			this->width = width;
			this->height = height;
			
			setData(data_ptr); 
			
			/*for (int i = 0; i < width * height; i++) {
				buffer[i] = data_ptr[i];//exoume diavasei ta stoixeia kai ta pername ston buffer
			}*/


		}

		template <typename T>
		Array2D<T>::Array2D(const Array2D& src):buffer(src.width*src.height) {//copy constr
			//epishs o buffer prin tou dwsoume timh einai 0 ara prepei na baloyme lista arxikokopoihshs wste na mporoume meta na 
			//tou baloume kai times (resize)
			width = src.width;
			height = src.height;
	

			for (int i = 0; i < width * height; i++) {
				buffer[i] = src.buffer[i];
			}
		}

		template <typename T>
	Array2D<T>::~Array2D() {//destr
		
	}


	template <typename T>
		Array2D<T> & Array2D<T>::operator = (const Array2D& right){//copy operator

			if (this != &right) {
				width = right.width;
				height = right.height;
	
				buffer.clear();

				for (int i = 0; i < width * height; i++) {
					buffer.push_back (right.buffer[i]);
				}
				
			}
			return*this;
		}



	



	}

