//h load pairnei san orisma thn (filename,format) kai ta dyo cpp

#include "image.h"
#include "../ppm/ppm.h"//epidh to ppm einai se allo project paw ena bhma pisw gia na brw ton fakelo
#include <iostream>
#include <vector>
//epeidh kalei thn ppm.cpp kai thn array2d vlepw to wifth to height kai to buffer
namespace image {
	//sthn load to filename einai to onoma tou  arxeioy
	//thelei na paroume thn katalhxh tou arxeiou kai na sygkrinouume an einai idio me to format = ppm

bool Image::load(const std::string& filename, const std::string& format) {
	int w;
	int h;
	//kalw thn read ppm
		string form= filename.substr(filename.length()-3 ,3); // apo poio shmeio tha xekinhsei na sou ferei to kommati,mexri pou
		if (form == format) {
			//H READ pairnei char * alla egw exw to onooma tou arxeio se string ara h metatroph ginetai me c_str
			float* pi = ReadPPM(filename.c_str(), &w, &h);//einai o pinakas pou exw ftiaxei sthn read flf w*h*3...r,g,b,r,g,b,r,g,b.....
			if (pi == nullptr) {
				cout << "error reading";
				return false;
			}
			else {
				//enhmerwsh deiktwn gia na xeroume pou eimaste
				width = w;
				height = h;
				buffer.resize(width * height);

				//thelw na perasw ton pi se buffer pou exei megethos w*h epeidh exei se ena koutaki to rgb
				for (int i = 0; i < w * h * 3; i = i + 3) {
					buffer[i / 3].r = pi[i];
					buffer[i / 3].g = pi[i+1];
					buffer[i / 3].b = pi[i+2];

				}
				delete[] pi;
				return true;

			}
			
		}
		else {
			cout << "not ppm file";
			return false;
		}

		 
	 }

	 bool Image::save(const std::string& filename, const std::string& format) {

		 //kanw thn aditheth diadikasia 
		 //twra den exw ton pi ,ton ftiaxnw
		 //exw ton buffer kai skorpizw ta stoixeia se xexwristes thseis
		 string form = filename.substr(filename.length() - 3, 3); // apo poio shmeio tha xekinhsei na sou ferei to kommati,mexri pou
		 if (form == format) {
			 cout << "its ok";



			 if (buffer.size() == 0) {
				 cout << "den upaexei h eikona";
				 return false;
			 }


			 float* newpi = new float[width * height * 3];
			 for (int i = 0; i < width * height * 3; i = i + 3) {
				 newpi[i] = buffer[i / 3].r;
				 newpi[i + 1] = buffer[i / 3].g;
				 newpi[i + 2] = buffer[i / 3].b;



			 }
			 bool o = WritePPM(newpi, width, height, filename.c_str());
			 delete[] newpi;
			 if (o == true) {
				 cout << "OK";
				 return true;

			 }
			 else {
				 return false;
			 }
		 }
		 else {
			 cout << "empty buffer";
			 return false;
		 }
	 }
}



