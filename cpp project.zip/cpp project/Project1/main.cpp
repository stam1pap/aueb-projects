


#include "FilterGamma.h"
#include "FilterLinear.h"
#include "Image.h"
#include "vec3.h"
#include <iostream>

using namespace std;
using namespace image;


int main(int argc, char* argv[])
{
	if (argc < 5) {

		cout << "error not enough elements";
		return 0;

	}
	string photo_path = argv[argc - 1]; // to path ths eikonas
	
	
	Image photo;     //diabasma eikonas
	bool elegxos = photo.load(photo_path, "ppm"); // h load epistrefei an katafere na fortwsei
	if (elegxos == true) {// an fortvse

		for (int i = 0; i < argc - 1; i++) 
		{ // den mporw na sygkrinw string me char* ara 8a kanw metatropi:
			string s = argv[i];
			if (s == "-f")
			{
				s = argv[i + 1];
				if(s== "gamma")
				{
					float gam = atof(argv[i + 2]);
					FilterGamma fg(gam);
					photo = fg << photo;
				}
				else if (s == "linear") 
				{
					float lin1 = atof(argv[i+2]);
					float lin2 = atof(argv[i+3]);
					float lin3 = atof(argv[i+4]);
					float lin4 = atof(argv[i+5]);
					float lin5 = atof(argv[i+6]);
					float lin6 = atof(argv[i+7]);

					Vec3<float>a(lin1, lin2, lin3);
					Vec3<float>c(lin4, lin5, lin6);
					FilterLinear fl (a, c);
					photo = fl << photo;  //xrhsh tou filtrou


				}
			}

		}
		
		photo_path.erase(photo_path.length() - 4);// sbhnei to .ppm
		photo_path = photo_path + "_filtered.ppm"; //bazei to neo onoma
		photo.save(photo_path, "ppm"); // eksagei thn photo

	}
	else { //an apetyxe h fortosh
		cout << "error den fortose h photo";
		return 0;
	}


}