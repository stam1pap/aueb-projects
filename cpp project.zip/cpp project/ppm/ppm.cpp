#include "ppm.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;
namespace image
{
	float* ReadPPM(const char* filename, int* w, int* h)
	{
		ifstream file = ifstream(filename, ios_base::in | ios_base::binary);
		//onoma arxeiou h to path,arxeio eisodou,stoixeia keimenou kai dyadika stoixeia
		if (file.is_open()) {
			string P6;
			float height, width,ent;
			float* table;//dhmiourgia dynamikou pinaka 
			file >> P6 >>  width >> height >> ent;
			float k = height * width * 3;
			table = new float[k]; //ypsos epi varos epi tria xrwmata to kathe pixel
			*w = width;
			*h = height;
			file.seekg(ios_base::cur, 1); //metakinoume to kersora ena byte dexia wste na paei ekei pou xekinaei to keimeno me ta dyadika stoixeia

			for (int i = 0; i < k; i += 3) {
				unsigned char r;// einai o monos tupos pou exei 8 bits/1 byte ,tosa osa theloume gia na apothhkefsoume to ena xrwma 
				unsigned char b;//0-255
				unsigned char g;
				file.read((char*)&r, sizeof(unsigned char));
				file.read((char*)&g, sizeof(unsigned char));
				file.read((char*)&b, sizeof(unsigned char));
				table[i] = r / 255.0;
				table[i + 1] = g / 255.0;//255/(0-255)=0-1
				table[i + 2] = b / 255.0;


			}
			file.close();
			return table;
		}
		else {
			cout << "Error opening file ";

			return nullptr;
			

		}


	}

	bool WritePPM(const float* data, int w, int h, const char* filename)

	{
		float k = h * w * 3;
		if (data==NULL) {
			return false;
			cout << "Error"; 
		}
		ofstream file = ofstream(filename, ios_base::out | ios_base::binary);

		if (file.is_open() ) {
			file << "P6" << endl;
			file << w << endl;
			file << h << endl;
			file << 255 << endl;

			for (int i = 0; i < k; i +=3) {
				unsigned char r;//o pinakas hdh periexei unsigned chars giati prin exoume kanei thn diaiaresh /255 opote gia na ta apo thhkefsw
				//twra prepei pali na ta poll/sw *255
				unsigned char g;
				unsigned char b;
				r = data[i] * 255;//apo 0-1 ta kanoume apo 0 ews 255
				g = data[i+1] * 255;
				b = data[i+2] * 255;

				file.write((char*)&r,sizeof(unsigned char));//exoume kai pali unsigned chars 
				file.write((char*)&g, sizeof(unsigned char));
				file.write((char*)&b, sizeof(unsigned char));
			}

			file.close();
			return true;
		}

		
		return false;
	}

}

