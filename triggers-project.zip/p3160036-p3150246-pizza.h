#ifndef HEADER_FILE
#define HEADER_FILE

#include <time.h>      // clock_gettime, timespec
#define NTEL 3         // # of tilefonites - tel operators
#define NCOOK 2        // # of psistes - cooks
#define NOVEN 10       // # of fournoi - ovens
#define NDELIVERER 7   // # of dianomeis - deliverers
#define TORDERLOW 1    // lepto - the lower bound of the time before the next order arrives
#define TORDERHIGH 5   // lepta - the upper bound of the time before the next order arrives
#define NORDERLOW 1    // pitsa - the lower bound of the number of pizzas for an order
#define NORDERHIGH 5   // pitses - the upper bound of the number of pizzas for the next order
#define TPAYMENTLOW 1  // lepto - the lower bound of the time one tel operator needs to charge the customer credit card
#define TPAYMENTHIGH 2 // lepta - the upper bound of the time one tel operator needs to charge the customer credit card
#define CPIZZA 10      // euro  - the cost of each pizza
#define PFAIL  5       // percent - the fail posibility
#define TPREP 1        // lepto - the time one cook needs to prepare one single pizza
#define TBAKE 10  	   // lepta - the time it takes for all the pizzas of the same order to be baked
#define TPACK 2		   // lepta - the time needed to pack the pizzas of an order
#define TDELLOW 5	   // lepta - the lower bound of the time a deliverer needs to deliver an order
#define TDELHIGH 15    // lepta - the upper bound of the time a deliverer needs to deliver an order


#define GOFAST 0       // if 1 low delays for testing purpose (use usleep instead of sleep)

//  10^9 nanoseconds = 1 second or 1 nanosecond = 10^(-9) seconds
#define BILLION 1000000000L // used to convert nanoseconds to seconds
#define MAX_WIDTH 3         // max width of the number of orders, used for formatting in printf

// Functions declaration
void display_available_resources(int tel,int cook, int oven,int pack, int deliverer);
void *order(void *x);
int posibility(unsigned int seed);
struct timespec timeDiff(struct timespec start,struct timespec end);
double timespec2sec(struct timespec t);
#endif
