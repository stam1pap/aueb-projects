gcc -pthread p3160036-p3150246-pizza.c -o pizza -lm
./pizza 100 1000