var img={}
   function zoomin() {

var platos=document.getElementById("Joomla").clientWidth;
var upsos=document.getElementById("Joomla").clientHeight;
         document.getElementById("Joomla").style.width = (platos + 200) + "px";
            document.getElementById("Joomla").style.height = (upsos + 200) + "px";}
       
          
function zoomout() {
            var platos = document.getElementById("Joomla").clientWidth;
            var ypsos= document.getElementById("Joomla").clientHeight;
       

            document.getElementById("Joomla").style.width = (platos - 200) + "px";
            document.getElementById("Joomla").style.height = (ypsos - 200) + "px";
       }

          function zoomin2() {

var platos=document.getElementById("Wordpress").clientWidth;
var upsos=document.getElementById("Wordpress").clientHeight;
         document.getElementById("Wordpress").style.width = (platos + 200) + "px";
            document.getElementById("Wordpress").style.height = (upsos + 200) + "px";}
       
          
function zoomout2() {
            var platos = document.getElementById("Wordpress").clientWidth;
            var ypsos= document.getElementById("Wordpress").clientHeight;
       

            document.getElementById("Wordpress").style.width = (platos - 200) + "px";
            document.getElementById("Wordpress").style.height = (ypsos - 200) + "px";
       }

/*var x = document.getElementsById("header");*/

  
     var flag=0;    
function changeCSS() {

  var x = document.getElementById("header");
   
  if ((x.className === "headerr")&& ( flag==0 )) { 
    x.style.color = "pink";
     flag=1;
  }
else if ((x.className === "headerr" )&& (flag==1)){
   x.style.color = "white";
   flag=0;}
}

function changefontstyle(){

var y = document.getElementById("header"); 
  var d = new Date();
  var n = d.getDay();


  if(n==4){
  y.style.color = "pink";}
  else if (n==2){ y.style.color = "#FF00FF";}
  else if (n==3){  y.style.color = "#FFB6C1";}
  else if (n==5){  y.style.color = "#ff1493";}
  else if (n==6){  y.style.color = "#FFE4E1";}
  else if (n==7){  y.style.color = "#DDA0DD";}
else if (n==1){  y.style.color = "#800080";}


  
}






