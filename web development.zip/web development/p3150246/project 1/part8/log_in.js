function checkPasswordMatch() {
    var password = document.getElementById('psw');
    var confirm_psw = document.getElementById('confirm_psw');
   
    var message = document.getElementById('confirmMessage');
    
    var correct = "#66cc66";
    var wrong = "#ff6666";

  if(password.value == confirm_psw.value){
        confirm_psw.style.backgroundColor = correct;
        message.style.color = correct;
        message.innerHTML = "Passwords Match!"
    }
    else{
        confirm_psw.style.backgroundColor = wrong;
        message.style.color = wrong;
        message.innerHTML = "Passwords Do Not Match!"
    }
}
