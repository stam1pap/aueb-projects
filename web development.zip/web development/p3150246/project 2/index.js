const express = require('express')
const exphbs = require('express-handlebars')
const path = require('path')
const bookAPP = require('./models/books')
const app = express()
const port = 8080

app.listen(port)

/* 
    Serve static content from directory "public",
    it will be accessible under path /static, 
    e.g. http://localhost:8080/static/index.html
*/
app.use('/static', express.static(__dirname + '/public'))

// Parse url-encoded content from body
app.use(express.urlencoded({ extended: false }))

// Parse application/json content from body
app.use(express.json())

// Set the render engine to use handlebars
app.engine("handlebars",exphbs());
app.set('view engine','handlebars');


app.get("/",function(req,res) {

    var options = {
        root: path.join(__dirname, 'public')
    }

    res.render('home');

})

app.get("/search",function(req,res) {

    var options = {
        root: path.join(__dirname, 'public')
    }

    res.render('search');

})


app.post('/search/api', function(req,res) {
    let tempBook = bookAPP.create(req.body.book_cover, req.body.book_title,req.body.book_author,req.body.book_workID);
    bookAPP.save(tempBook);
    
});

app.post('/search/api/remove', function(req,res) {

    let tempBook = bookAPP.create(req.body.book_cover, req.body.book_title,req.body.book_author,req.body.book_workID);
    bookAPP.remove(tempBook);
    
});

app.get('/favorite', function(req, res){
    
    var options = {
        root: path.join(__dirname, 'public')
    }

    const jsonString = JSON.stringify(bookAPP.findAll());
    const listOfBooks = JSON.parse(jsonString);

    res.render('book_component',{ books  : listOfBooks });
})

app.post('/favorite', function(req, res){
    res.send('404');
});

app.get('/favorite/:title', function(req, res){
    
    var options = {
        root: path.join(__dirname, 'public')
    }
    let jsonString;

    if(req.params.title == -1)
    {
        jsonString = JSON.stringify(bookAPP.findAll());
    }
    else
    {
        jsonString = JSON.stringify(bookAPP.findByTitle(req.params.title));
        
    }
    
    const listOfBooks = JSON.parse(jsonString);
    res.send(listOfBooks);
})

app.get('/editor/:workid', async function(req,res) {
    
    const jsonString = JSON.stringify(bookAPP.findByID(req.params.workid)[0]);
    const listOfBooks = JSON.parse(jsonString);
    console.log(listOfBooks);
    res.render('book_editor',listOfBooks)

});

app.post('/editor/update', async function(req,res) {

    let book = {
        id: req.body.workID,
        title: req.body.title,
        author: req.body.author,
        rating: req.body.rating
    }
    bookAPP.update(book);
    res.redirect('/favorite');
    
});