let Book = /** @class */ (function () {
    function Book(workID,imgSrc, title, author) {

        if (this.workID === undefined) {
            this.workID = null;
        }

        if (this.imgSrc === undefined) {
            this.imgSrc = null;
        }
        if (this.title === undefined) {
            this.title = null;
        }
        if (this.author === undefined) {
            this.author = null;
        }
        this.imgSrc = imgSrc;
        this.title = title;
        this.author = author;
        this.workID = workID;
        this.rating = "";
    }
    Book.prototype.getTitle = function () {
        return this.title;
    };
    Book.prototype.setTitle = function (title) {
        this.title = title;
    };
    Book.prototype.getWorkID = function () {
        return this.workID;
    };
    Book.prototype.setWorkID = function (workID) {
        this.workID = workID;
    };
    Book.prototype.getAuthor = function () {
        return this.author;
    };
    Book.prototype.setAuthor = function (author) {
        this.author = author;
    };
    Book.prototype.setRating = function (rating) {
        this.rating = rating;
    };
    Book.prototype.getAuthor = function () {
        return rating;
    };
    return Book;
}());

let books = new Map();


function create(imgSrc,title,author,workID) { return new Book(workID,imgSrc,title,author); }

function save(book) {

    let exists = false;

    for (let [key, value] of books) {
        if(value.getTitle() === book.getTitle()) {
            exists = true;
        }
    }

    if( !exists )
    {
        console.log("New book has been created!");
        books.set(book.getWorkID(),book);
    }
}

function remove(book) {
    books.delete(book.getWorkID());
}

function findAll() {
    let myList = new Array();
    books.forEach(function(value, key) {
        myList.push(value);
      });
    return myList;
}

function findByID(id) {
    let myList = new Array();
    books.forEach(function(value, key) {
        if(value.getWorkID() == id)
            myList.push(value);
      });

    return myList;
}

function update(book) {
    books.forEach(function(value, key) {
        if(value.getWorkID() == book.id)
        {
            value.setWorkID( book.id );
            value.setAuthor( book.author );
            value.setTitle( book.title );
            value.setRating( book.rating );
            books.set(book.id,value);
        } 
      });
}

function findByTitle(title) {
    let myList = new Array();
    books.forEach(function(value, key) {
        if(value.getTitle().includes(title))
        {
            myList.push(value);
        }
    });
    return myList;
}


module.exports = {
    create,
    save,
    findAll,
    findByID,
    findByTitle,
    remove,
    update,
    Book
}