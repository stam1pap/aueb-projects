document.addEventListener('click',function(evt){
    if(evt.target && evt.target.className== 'editMe'){
        let parent = evt.target.parentNode;

        while (!parent.classList.contains('book')) {
            parent = parent.parentNode;
        }

        let id = {myid : parent.id};
     }
 });


 //setup before functions
let typingTimer;                //timer identifier
let doneTypingInterval = 1500;  //time in ms (1.5 seconds)
let myInput = document.getElementById('search-bar');

//on keyup, start the countdown
myInput.addEventListener('keyup', () => {
    clearTimeout(typingTimer);

        typingTimer = setTimeout(doneTyping, doneTypingInterval);

});

const sd = `    {{#each books}}
<div class="book read" id="{{workID}}">
    <div class="cover">
        <img  alt="{{title}}" src="{{{imgSrc}}}">
    </div>
    <div class="description">
        <p class="title"> <strong class="webtitle">{{title}} </strong> </br>
        <span class="author">{{author}}</span></p>
        <a href="/editor/{{workID}}"><button class="editMe">Edit</button></a> 
    </div>
</div>
{{/each}}`;

//user is "finished typing," do something
function doneTyping () {
    let searchValue;
    if(myInput.value.length == 0)
        searchValue = -1;
    else
        searchValue = myInput.value;
    fetch("/favorite/"+searchValue)
    .then( res => res.text())
    .then( data => {
        
        let view = Handlebars.compile(sd);

        const result = view({books:JSON.parse(data)});
        document.getElementById("results").innerHTML = result;
    })
}

