const API_URL = "https://reststop.randomhouse.com/resources/titles"
const getBtn = document.getElementById('search_button');


function booksearch() {
    console.log("Executing book search!");
    var title = document.getElementById('search_books').value;
    if (title) {
        console.log(title);
    }
}

const getBooksByTitle = () => {
    console.log("Executing book search!");
    var title = document.getElementById('search_books').value;

    let myHeaders = new Headers();
    myHeaders.append('Accept','application/json');

    let init = {
        method: "GET",
        headers: myHeaders
    }

    

    fetch(API_URL+"?search="+title,init)
        .then(response => response.json())
        .then(obj => {
            console.log(obj);
            let books = obj.title;
            
            let mainContainer = document.getElementById("results");
            let template = document.getElementById('some-template').innerHTML;
            let renderProfile = Handlebars.compile(template);

            let mainData = [];
            for(i=0; i<books.length; i++)
            {
                books[i]['imgSrc'] = books[i]['@uri'];
                mainData += renderProfile(books[i]);
            }


            mainContainer.innerHTML = mainData;
        })
    .catch(function (err) {
        console.log(err);
    });


};


// Using event delegation
document.addEventListener('click',function(evt){
    if(evt.target && evt.target.className== 'saveMe'){
        let parent = evt.target.parentNode;

        while (!parent.classList.contains('book')) {
            parent = parent.parentNode;
        }
        
        save(parent);

        parent.getElementsByClassName('removeMe')[0].disabled = false;
        parent.getElementsByClassName('saveMe')[0].disabled = true;
        parent.getElementsByClassName('bookStoreMessage')[0].innerHTML = "Saved";
     }
 });

 document.addEventListener('click',function(evt){
    if(evt.target && evt.target.className== 'removeMe'){
        let parent = evt.target.parentNode;

        while (!parent.classList.contains('book')) {
            parent = parent.parentNode;
        }
        
        remove(parent);

        parent.getElementsByClassName('removeMe')[0].disabled = true;
        parent.getElementsByClassName('saveMe')[0].disabled = false;
        parent.getElementsByClassName('bookStoreMessage')[0].innerHTML = "Removed";
     }
 });




if(getBtn)
    getBtn.addEventListener('click',getBooksByTitle,false);


function save(book_element) {

    let imgSrc = book_element.getElementsByTagName('img')[0].getAttribute('src');
    let title = book_element.getElementsByTagName('strong')[0].innerHTML;
    let author = book_element.getElementsByTagName('span')[0].innerHTML;
    let workID = book_element.id;

    const obj = { book_cover: imgSrc, book_title: title, book_author: author, book_workID: workID };

    let init_post = {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(obj)
    }

    fetch('/search/api',init_post);
}

function remove(book_element) {

    let imgSrc = book_element.getElementsByTagName('img')[0].getAttribute('src');
    let title = book_element.getElementsByTagName('strong')[0].innerHTML;
    let author = book_element.getElementsByTagName('span')[0].innerHTML;
    let workID = book_element.id;

    const obj = { book_cover: imgSrc, book_title: title, book_author: author, book_workID: workID };

    let init_post = {
        method: "POST",
        headers: {
            "Content-type": "application/json"
        },
        body: JSON.stringify(obj)
    }

    fetch('/search/api/remove',init_post);
}